<?

define ('Lang', 'en');
define ('DEFAULT_CUR', 'USD');


$currency = array(
	'USD'=>array('rate'=>1, 'symbol' =>'$'),
	'Euro'=>array('rate'=>1.3, 'symbol' =>'&euro;')
);

$lang = array(
	'ru',
	'en'
);

$cart = array (
	0=>array(
		'min'=>0,
		'max'=>100,
		'AirMail'=>10,
		'Courier'=>16.95
	),
	1=>array(
		'min'=>100,
		'max'=>1000,
		'AirMail'=>10,
		'Courier'=>16.95
	),
)

?>
