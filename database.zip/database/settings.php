<?

define ('Lang', 'en');
define ('DEFAULT_CUR', 'USD');

$checkout_type="checkout1";

$currency = array(
	'USD'=>array('rate'=>1, 'symbol' =>'$'),
	'Euro'=>array('rate'=>1.3, 'symbol' =>'&euro;')
);

$lang = array(
	'ru',
	'en'
);

$cart_settings = array (
	0=>array(
		'min'=>0,
		'max'=>100,
		'AirMail'=>10,
		'Courier'=>16.95
	),
	1=>array(
		'min'=>100,
		'max'=>1000,
		'AirMail'=>0,
		'Courier'=>5.95
	)
);

$discount_codes = array (
	0=>array(
		'code'=>'827ccb0eea8a706c4c34a16891f84e7b',
		'discount'=>3
	)
);

?>
