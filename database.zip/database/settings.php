<?

define ('Lang', 'en');
define ('DEFAULT_CUR', 'USD');


$currency = array(
	'USD'=>array('rate'=>1, 'symbol' =>'$'),
	'Euro'=>array('rate'=>1.3, 'symbol' =>'&euro;')
);

$lang = array(
	'ru',
	'en'
);

?>
