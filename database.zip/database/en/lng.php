<?
$lng = array(
	'lbl_menu_home'=>'Home',
	'lbl_menu_bestsellers'=>'Bestsellers',
	'lbl_menu_all_products'=>'All products',
	'lbl_menu_faq'=>'FAQ',
	'lbl_menu_testimonials'=>'Testimonials',
	'lbl_menu_contacts'=>'Contacts',

	'lbl_product_list'=>'Product list',
	'lbl_products'=>'Products',
	'lbl_all_products'=>'All products',
	'lbl_more_info'=>'More info',
	'lbl_cap_order_now'=>'ORDER NOW',
	'lbl_search_by_name'=>'Search by name:',


	'lbl_shipping_policy'=>'Shipping policy',
	'lbl_moneyback_policy'=>'Moneyback policy',
	'lbl_privacy_policy'=>'Privacy policy',
	'lbl_report_spam'=>'Report spam',
	'lbl_contact_us'=>'Contact us',
	'lbl_footer_contactus'=>'You may contact us at +1(210) 888-9089, please, keep your order I.D. every time you make a call.',
	'lbl_we_accept'=>'We accept',

	'lbl_add_to_cart'=>'Add to cart &raquo;',
	'lbl_our_price'=>'Our price',
	'lbl_nothing_found'=>'Nothing Found',

	'lbl_learn_more'=>'Learn more',
	'lbl_product_description'=>'Product description',
	'lbl_safety_information'=>'Safety information',
	'lbl_side_effects'=>'Side Effects',

	'lbl_quantity'=>'Quantity',
	'lbl_price'=>'Price',
	'lbl_per_pill'=>'Per Pill',
	'lbl_savings'=>'Savings',

	'lbl_product_name'=>'Product name',
	'lbl_quantitye'=>'Quantity',
	'lbl_total'=>'Total',
	'lbl_remove'=>'Remove',

	'lbl_empty_cart'=>'Your cart is empty!',


)
?>
